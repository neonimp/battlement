# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['battlement', 'battlement.conditions', 'battlement.failfast']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'battlement',
    'version': '0.1.0',
    'description': 'Defensive programming library for python',
    'long_description': None,
    'author': 'Matheus Xavier',
    'author_email': 'mxavier@mail.cmdforge.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
